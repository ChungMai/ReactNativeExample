import { useEffect, useState } from 'react'

type FetchState<T> = { data: T | null; loading: boolean; error: string | null }

/** Loads JSON from `url` and cancels the request on unmount or when `url` changes. */
export function useFetch<T>(url: string): FetchState<T> {
  const [state, setState] = useState<FetchState<T>>({ data: null, loading: true, error: null })

  useEffect(() => {
    const controller = new AbortController()
    setState({ data: null, loading: true, error: null })

    fetch(url, { signal: controller.signal })
      .then(res => (res.ok ? res.json() : Promise.reject(new Error(`HTTP ${res.status}`))))
      .then((data: T) => setState({ data, loading: false, error: null }))
      .catch((e: Error) => {
        if (e.name !== 'AbortError') setState({ data: null, loading: false, error: e.message })
      })

    return () => controller.abort()
  }, [url])

  return state
}
