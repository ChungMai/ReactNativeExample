import { useEffect, useRef } from 'react'

/** Remembers the value from the previous render (a ref does not trigger re-renders). */
export function usePrevious<T>(value: T): T | undefined {
  const ref = useRef<T | undefined>(undefined)
  useEffect(() => {
    ref.current = value
  })
  return ref.current
}
